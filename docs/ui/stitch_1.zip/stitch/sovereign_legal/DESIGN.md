# The Design System: Architectural Trust & Editorial Prestige

## 1. Overview & Creative North Star: "The Digital Jurist"
This design system moves away from the "software-as-a-service" aesthetic and toward a "digital institution." The Creative North Star is **The Digital Jurist**: a visual language that feels as deliberate and authoritative as a leather-bound legal brief, yet as fluid as modern justice. 

We break the "template" look by rejecting rigid, boxy grids in favor of **Intentional Asymmetry** and **Editorial Breathing Room**. We utilize high-contrast typography scales—pairing the razor-sharp serifs of the courtroom with the hyper-functional sans-serifs of modern tech—to create a hierarchy that feels both prestigious and accessible. Layouts should prioritize large "silences" (white space) to allow complex legal information to breathe, ensuring the user feels a sense of calm and clarity.

---

## 2. Colors: Tonal Authority
The palette is rooted in tradition but executed with modern depth. We do not use "flat" colors; we use "surfaces."

| Token | Hex | Role |
| :--- | :--- | :--- |
| `primary` | #1B2A4A | Deep Navy: The foundation of authority. Use for core actions. |
| `secondary` | #C9A84C | Warm Gold: The "Seal of Excellence." Use for high-prestige accents. |
| `surface` | #FBF9F4 | Warm Ivory: A sophisticated alternative to pure white, reducing eye strain. |
| `tertiary` | #2E7D5E | Muted Emerald: Used for success states and growth indicators. |

### The "No-Line" Rule
Prohibit 1px solid borders for sectioning. Structural boundaries must be defined solely through background color shifts. For example, a `surface-container-low` section should sit on a `surface` background to create a "neighborhood" of content without the visual clutter of lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
- **The Base:** `surface` (#FBF9F4)
- **The Card:** `surface-container-lowest` (#FFFFFF) placed atop `surface-container-low` (#F5F3EE).
- **The Detail:** Use `surface-container-highest` (#E4E2DD) for small utility areas like sidebars or meta-data trays to push them "behind" the main content.

### Signature Textures
Avoid flat primary buttons. Apply a subtle linear gradient from `primary` (#1B2A4A) to `primary-container` (#1B2A4A at 85% opacity) to provide a soft, light-catching "sheen" that mimics high-end stationery.

---

## 3. Typography: The Editorial Contrast
We pair the historical weight of the serif with the clarity of the sans-serif.

*   **Display & Headlines (Cormorant Garamond / Newsreader):** These are our "Voice of Authority." Use `display-lg` (3.5rem) for hero statements. The high x-height and sharp terminals convey a sense of history and precision.
*   **Body & UI (Inter):** The "Voice of Reason." Inter provides maximum readability for dense legal text. Use `body-md` (0.875rem) for standard content to maintain a modern, clean feel.
*   **The Signature Scale:** Always use a minimum 2:1 ratio between headline and body size to ensure the "Editorial" look. Titles should never feel like they are "competing" with the text below them.

---

## 4. Elevation & Depth: Tonal Layering
In this design system, shadows and borders are a last resort. Depth is a matter of light and material.

*   **The Layering Principle:** Stack `surface-container` tiers to create hierarchy. A `surface-container-lowest` card on a `surface-container-low` section creates a natural "lift."
*   **Ambient Shadows:** For floating elements (Modals, Dropdowns), use a "Lawyer’s Shadow": `box-shadow: 0 12px 40px rgba(27, 28, 25, 0.06)`. It must be barely perceptible, mimicking ambient office light.
*   **The Ghost Border Fallback:** If a container needs more definition, use `outline-variant` (#C5C6CF) at **15% opacity**. This creates a "suggestion" of a container without breaking the editorial flow.
*   **Glassmorphism:** For top navigation bars, use `surface` at 80% opacity with a `backdrop-filter: blur(12px)`. This makes the platform feel integrated and premium, allowing content to flow underneath the "frosted glass" header.

---

## 5. Components: Precision Elements

### Buttons
*   **Primary:** Deep Navy (#1B2A4A), 8px corner radius. No border. White text. Subtle sheen gradient.
*   **Secondary (Prestige):** Warm Gold (#C9A84C) background with `on-secondary-fixed` text. Used for "Start Consultation" or "Upgrade."
*   **Tertiary:** Ghost style. No background, `primary` text. Use for "Cancel" or "Back."

### Cards
*   **The Rule:** No borders. Use `surface-container-lowest` (#FFFFFF) on a `surface` (#FBF9F4) background.
*   **Corners:** Use the `md` (0.75rem / 12px) token for a soft, professional curve that feels intentional but not "bubbly."

### Input Fields
*   **Interaction:** On focus, the field should not gain a heavy border. Instead, the background should shift from `surface-container-highest` to `surface-container-lowest`, and the label should transition to `primary`.

### List Items & Dividers
*   **Prohibition:** Forbid the use of horizontal divider lines.
*   **Alternative:** Use `1.5rem` of vertical white space or a subtle background toggle (zebra striping using `surface-container-low`) to separate individual legal case items or documents.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace Asymmetry:** Place a large serif headline on the left with a smaller, narrower body block on the right to create an editorial, "newspaper" feel.
*   **Use Tonal Transitions:** Use background colors to guide the eye from one section to the next.
*   **Prioritize Typography:** Let the font do the heavy lifting. A well-set `display-md` header is more powerful than any icon or illustration.

### Don't:
*   **Don't use 100% Black:** Always use `primary` or `on-surface` (#1B1C19) for text to keep the "Ivory & Navy" warmth.
*   **Don't use Rounded Buttons (Pills):** Keep buttons at `8px - 12px` radius. Full rounded "pills" feel too casual for a prestigious legal environment.
*   **Don't Over-Iconize:** Use icons sparingly. When used, ensure they are thin-line professional styles (1.5px stroke) in `primary`.