# Design System Specification: The Digital Atelier of Law

## 1. Overview & Creative North Star
**The Creative North Star: "The Sovereign Archive"**

This design system rejects the frantic, "disruptive" aesthetic of common SaaS platforms. Instead, it draws inspiration from the quiet authority of a high-end law library and the surgical precision of modern fintech. We aim for a "Sovereign Archive" look—an environment that feels permanent, curated, and impeccably organized.

To move beyond the "template" look, this system utilizes **Intentional Asymmetry**. While the underlying logic is grounded in a 12-column grid, key editorial moments—such as hero headers or data summaries—should utilize expansive whitespace and off-center alignments to create a sense of bespoke craftsmanship. We are building a digital "atelier" for legal professionals, where every pixel conveys credibility and calm.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
Our palette is rooted in the heritage of deep navy and charcoal, contrasted against a bright, airy background. 

### Core Palette
- **Primary (`#041627`):** To be used for high-level branding and primary navigation backgrounds.
- **Primary Container (`#1A2B3C`):** The workhorse for deep-toned components.
- **Tertiary/Accent (`#D4AF37` / `#735C00`):** Soft Gold. Use sparingly as a "hallmark" of quality—reserved for signature actions or validated states.
- **Surface (`#F8F9FA`):** The foundation. Everything sits on this crisp, neutral base.

### The "No-Line" Rule
Standard UI relies on 1px borders to separate content. **This system prohibits them.** To section off the interface, use background shifts rather than lines.
- **Rule:** Define boundaries using the `surface-container` tiers. A `surface-container-low` section sitting on a `surface` background creates a clear, sophisticated boundary that feels integrated, not "boxed in."

### Signature Textures & Glass
- **The Tonal Gradient:** For primary CTAs, do not use flat colors. Use a subtle linear gradient from `primary` to `primary-container` (top-to-bottom) to give the button "weight" and a tactile, premium feel.
- **Glassmorphism:** Use for floating panels or dropdown menus. Apply a semi-transparent `surface-container-lowest` with a `20px` backdrop-blur. This ensures the UI feels like layered vellum rather than flat digital cards.

---

## 3. Typography: The Editorial Balance
We pair the authoritative weight of a Serif with the clinical clarity of a Sans-Serif to create an "Editorial Tech" hierarchy.

- **Display & Headlines (Noto Serif):** These are our "Voice of Authority." Use `display-lg` through `headline-sm` for page titles and section headers. High-contrast sizing (e.g., a massive `display-md` next to a small `body-md`) creates a luxury magazine feel.
- **Body & Titles (Inter):** These are our "Voice of Logic." Inter is used for all functional data, inputs, and long-form legal text to ensure maximum readability and a modern fintech edge.
- **Labeling:** Use `label-sm` in all-caps with `0.05em` letter-spacing for metadata to evoke the look of a cataloged legal brief.

---

## 4. Elevation & Depth: Tonal Layering
In this system, depth is a matter of "stacking" rather than "shadowing."

### The Layering Principle
Instead of traditional drop shadows, create hierarchy through the `surface-container` scale:
1.  **Level 0 (Base):** `surface` (`#F8F9FA`)
2.  **Level 1 (Sectioning):** `surface-container-low` (`#F3F4F5`)
3.  **Level 2 (Active Cards):** `surface-container-lowest` (`#FFFFFF`)

### Ambient Shadows & Ghost Borders
- **Shadows:** Only use shadows for "floating" elements (Modals, Popovers). Use a large blur (`32px`) and very low opacity (`4%` of `on-surface`). This mimics natural ambient light in a bright room.
- **The Ghost Border Fallback:** If a border is required for accessibility on an input, use `outline-variant` at **20% opacity**. Never use 100% opaque borders; they disrupt the "Sovereign Archive" flow.

---

## 5. Components: Precision Elements

### Buttons
- **Primary:** Gradient from `primary` to `primary-container`. `4px` corner radius. White text (`on-primary`). 
- **Secondary:** `surface-container-highest` background with `primary` text. No border.
- **Tertiary (Ghost):** No background. `primary` text. Underline only on hover.

### Cards & Lists
- **Rule:** **Forbid 1px divider lines.** 
- Separate list items using the **Spacing Scale** (vertical whitespace) or by alternating background colors between `surface` and `surface-container-low`.
- **Shape:** All cards use a `0.375rem` (md) corner radius—rounded enough to feel modern, sharp enough to feel professional.

### Input Fields
- **Style:** Understated. Use `surface-container-lowest` background with a 10% `outline` ghost border. 
- **States:** On focus, the border shifts to `primary` (100% opacity) with a subtle `2px` glow of `surface-tint`.

### Specialized Legal Components
- **The Document Tray:** A persistent `surface-container-high` side panel using glassmorphism to show "active" case files without obscuring the main workspace.
- **Status Pills:** Use `tertiary-container` (Muted Gold) for "Pending" and `muted-teal` for "Executed." Avoid bright "traffic light" reds and greens; stay muted and professional.

---

## 6. Do’s and Don’ts

### Do:
- **Do** embrace extreme whitespace. High-end design breathes.
- **Do** use `notoSerif` for numbers in data dashboards to give them a "financial report" prestige.
- **Do** use "Ghost Borders" at 10-20% opacity only when strictly necessary.

### Don’t:
- **Don’t** use shadows to define every card. Use background tonal shifts instead.
- **Don’t** use playful illustrations. Use professional, thin-stroke (1.5px) outline icons.
- **Don’t** use pure black (`#000000`). Use `primary` or `on-surface` for all text to maintain the navy-charcoal depth.
- **Don’t** use "Startup Blue" (#007AFF). Use our `primary` (#041627) to maintain the law-firm credibility.